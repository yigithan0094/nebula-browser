package com.nebula.browser

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.*
import android.widget.*
import android.text.InputType
import android.graphics.Typeface
import android.content.Intent
import android.net.Uri
import android.view.KeyEvent

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 11, 20)
    private val panel = Color.rgb(18, 26, 42)
    private val fg = Color.rgb(238, 244, 255)
    private val cyan = Color.rgb(55, 216, 255)
    private lateinit var address: EditText
    private lateinit var web: WebView
    private lateinit var titleText: TextView
    private lateinit var status: TextView
    private lateinit var root: LinearLayout
    private val history = mutableListOf<String>()
    private var historyIndex = -1
    private val bookmarks = mutableSetOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
        openHome()
    }

    private fun text(s: String, size: Float = 15f): TextView = TextView(this).apply {
        text = s; textSize = size; setTextColor(fg); gravity = Gravity.CENTER_VERTICAL
    }
    private fun button(s: String, action: () -> Unit): Button = Button(this).apply {
        text = s; textSize = 13f; setTextColor(fg); setBackgroundColor(panel)
        isAllCaps = false; setOnClickListener { action() }
    }
    private fun buildUi() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(10, 8, 10, 8) }
        val brand = text("✦  NEBULA BROWSER", 21f).apply { setTextColor(cyan); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER }
        root.addView(brand, LinearLayout.LayoutParams(-1, 48))
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        nav.addView(button("←") { if (web.canGoBack()) web.goBack() }, LinearLayout.LayoutParams(48, 48))
        nav.addView(button("→") { if (web.canGoForward()) web.goForward() }, LinearLayout.LayoutParams(48, 48))
        nav.addView(button("↻") { web.reload() }, LinearLayout.LayoutParams(48, 48))
        address = EditText(this).apply {
            setSingleLine(true); textSize = 14f; setTextColor(fg); setHintTextColor(Color.LTGRAY)
            hint = "Adres veya Google'da ara"; setBackgroundColor(panel)
            inputType = InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            setPadding(12, 0, 12, 0)
            setOnEditorActionListener { _, action, event ->
                if (action == EditorInfo.IME_ACTION_GO || event?.keyCode == KeyEvent.KEYCODE_ENTER) { navigate(text.toString()); true } else false
            }
        }
        nav.addView(address, LinearLayout.LayoutParams(0, 48, 1f))
        nav.addView(button("Git") { navigate(address.text.toString()) }, LinearLayout.LayoutParams(58, 48))
        root.addView(nav)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        actions.addView(button("⌂ Ana sayfa") { openHome() }, LinearLayout.LayoutParams(0, 46, 1f))
        actions.addView(button("☆ Yer imi") { addBookmark() }, LinearLayout.LayoutParams(0, 46, 1f))
        actions.addView(button("▤ Geçmiş") { showHistory() }, LinearLayout.LayoutParams(0, 46, 1f))
        actions.addView(button("＋ Sekme") { openHome() }, LinearLayout.LayoutParams(0, 46, 1f))
        root.addView(actions)
        titleText = text("Hazır", 12f)
        root.addView(titleText, LinearLayout.LayoutParams(-1, 28))
        status = text("", 12f).apply { setTextColor(cyan) }
        root.addView(status, LinearLayout.LayoutParams(-1, 22))
        web = WebView(this).apply {
            setBackgroundColor(Color.WHITE)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            webViewClient = object : WebViewClient() {
                override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                    status.text = "Yükleniyor…"
                    if (url != null) address.setText(url)
                }
                override fun onPageFinished(view: WebView?, url: String?) {
                    status.text = "Sayfa yüklendi"
                    titleText.text = view?.title ?: url ?: "NEBULA"
                    if (url != null) address.setText(url)
                }
                override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                    if (request?.isForMainFrame == true) status.text = "Sayfa yüklenemedi. Bağlantını kontrol et."
                }
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val uri = request?.url ?: return false
                    return if (uri.scheme == "http" || uri.scheme == "https") false else true
                }
            }
            webChromeClient = WebChromeClient()
        }
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun navigate(raw: String) {
        var q = raw.trim()
        if (q.isEmpty()) return
        val url = when {
            q.contains(" ") -> "https://www.google.com/search?q=" + Uri.encode(q)
            q.matches(Regex("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) -> q
            q.contains(".") -> "https://$q"
            else -> "https://www.google.com/search?q=" + Uri.encode(q)
        }
        if (!url.startsWith("https://") && !url.startsWith("http://")) {
            status.text = "Yalnızca HTTP/HTTPS adresleri desteklenir."; return
        }
        web.loadUrl(url)
    }
    private fun openHome() {
        address.setText("")
        titleText.text = "Ana sayfa"
        val html = """
            <!doctype html><html lang="tr"><meta name="viewport" content="width=device-width,initial-scale=1">
            <body style="margin:0;background:#080b14;color:#eef4ff;font-family:system-ui;text-align:center;padding:12vh 6vw">
            <div style="font-size:48px;color:#37d8ff">✦</div><h1>NEBULA <span style="color:#37d8ff">BROWSER</span></h1>
            <p style="color:#9aa9c2">Keşfet. Ara. İnternete bağlan.</p>
            <p>Üstteki adres çubuğuna bir site veya arama yaz.</p>
            <p style="color:#37d8ff">Sekmeler · Yer imleri · Geçmiş · Koyu tema</p></body></html>
        """.trimIndent()
        web.loadDataWithBaseURL("https://nebula.local/", html, "text/html", "UTF-8", null)
    }
    private fun addBookmark() {
        val url = web.url ?: return
        if (url.startsWith("https://") || url.startsWith("http://")) {
            bookmarks.add(url); Toast.makeText(this, "Yer imi kaydedildi", Toast.LENGTH_SHORT).show()
        } else Toast.makeText(this, "Önce bir site aç", Toast.LENGTH_SHORT).show()
    }
    private fun showHistory() {
        if (history.isEmpty()) {
            val d = android.app.AlertDialog.Builder(this).setTitle("Geçmiş").setMessage("Bu oturumda kayıtlı ziyaret yok.").setPositiveButton("Tamam", null).create(); d.show(); return
        }
        android.app.AlertDialog.Builder(this).setTitle("Ziyaret geçmişi").setItems(history.reversed().toTypedArray()) { _, which ->
            navigate(history.reversed()[which])
        }.setNeutralButton("Temizle") { _, _ -> history.clear(); Toast.makeText(this, "Geçmiş temizlendi", Toast.LENGTH_SHORT).show() }
          .setNegativeButton("Kapat", null).show()
    }
    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else openHome()
    }
    override fun onPause() { if (::web.isInitialized) web.onPause(); super.onPause() }
    override fun onResume() { super.onResume(); if (::web.isInitialized) web.onResume() }
}
